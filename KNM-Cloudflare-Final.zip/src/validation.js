export const languages=['nl','ar','uk','so','ckb'];
export function safeURL(v){return typeof v==='string' && (v===''||/^https:\/\/[^\s<>"']+$/.test(v)||/^(?:assets\/|\/media\/)[a-zA-Z0-9_./-]+$/.test(v))&&!v.includes('..');}
function fail(m){throw new Error(m);}
function text(v,max=10000){if(typeof v!=='string'||v.length>max)fail('Invalid text');return v;}
export function validateQuestion(q){
 if(!q||!/^[-a-zA-Z0-9_]{1,80}$/.test(q.id))fail('Invalid ID');
 if(!Array.isArray(q.answers)||q.answers.length<2||q.answers.length>12)fail('Use 2–12 answers');
 if(!Number.isInteger(q.correct)||q.correct<0||q.correct>=q.answers.length)fail('Invalid correct answer');
 for(const l of languages){if(!text(q.text?.[l]).trim())fail('Complete all five translations');for(const a of q.answers)if(!text(a?.[l],4000).trim())fail('Complete all answer translations');text(q.imageAlt?.[l]||'');text(q.explanation?.[l]||'');}
 if(!safeURL(q.image||''))fail('Invalid image URL');
 for(const k of ['category','level'])text(q[k]||'',100);
 if(q.hidden!==undefined&&typeof q.hidden!=='boolean')fail('Invalid visibility');
 if(q.order!==undefined&&(!Number.isInteger(q.order)||Math.abs(q.order)>100000))fail('Invalid order');
 if(!Array.isArray(q.packIds)||!q.packIds.length||q.packIds.some(n=>!Number.isInteger(n)||n<1||n>6))fail('Choose packs 1–6');
 if(q.source && (!Number.isInteger(q.source.book)||q.source.book<1||q.source.book>3||!Number.isInteger(q.source.page)||q.source.page<1||q.source.page>(q.source.book===3?99:65)))fail('Invalid source page');
 return q;
}
export function validateSettings(s){
 for(const k of ['title','header','footer','icon'])text(s[k],2000);
 for(const k of ['logo','background'])if(!safeURL(s[k]))fail('Invalid image URL');
 for(const k of ['primary','secondary'])if(!/^#[0-9a-fA-F]{6}$/.test(s[k]))fail('Invalid color');
 if(!['system-ui','Arial','Tahoma','Georgia'].includes(s.font))fail('Invalid font');
 if(!Number.isInteger(s.fontSize)||s.fontSize<12||s.fontSize>28)fail('Font size 12–28');
 if(!Number.isInteger(s.minutes)||s.minutes<1||s.minutes>240)fail('Timer 1–240');
 if(!['welcome-first','controls-first'].includes(s.sectionOrder)||typeof s.showFilters!=='boolean')fail('Invalid layout');
 for(const k of ['categories','levels']){if(!Array.isArray(s[k])||s[k].length>100)fail('Invalid filters');s[k].forEach(v=>text(v,100));}
 if(!Array.isArray(s.navigation)||s.navigation.length>20)fail('Invalid navigation');
 s.navigation.forEach(n=>{text(n.label,100);if(!/^https:\/\/[^\s<>"']+$/.test(n.url))fail('Navigation requires HTTPS');});
 return s;
}
