import {validateQuestion,validateSettings} from './validation.js';
const json=(data,status=200,headers={})=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers}});
const hex=b=>[...new Uint8Array(b)].map(v=>v.toString(16).padStart(2,'0')).join('');
const hash=async s=>hex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));
const random=()=>hex(crypto.getRandomValues(new Uint8Array(32)));
async function password(p,salt){const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(p),'PBKDF2',false,['deriveBits']);return hex(await crypto.subtle.deriveBits({name:'PBKDF2',salt:new TextEncoder().encode(salt),iterations:100000,hash:'SHA-256'},key,256));}
function equal(a,b){if(typeof a!=='string'||typeof b!=='string'||a.length!==b.length)return false;let n=0;for(let i=0;i<a.length;i++)n|=a.charCodeAt(i)^b.charCodeAt(i);return n===0;}
async function body(r,max=262144){if(Number(r.headers.get('content-length'))>max)throw Error('Body too large');const b=await r.text();if(b.length>max)throw Error('Body too large');return JSON.parse(b);}
async function auth(r,e){const token=(r.headers.get('cookie')||'').match(/(?:^|;\s*)knm_session=([a-f0-9]{64})(?:;|$)/)?.[1];if(!token)return null;return e.DB.prepare('SELECT * FROM sessions WHERE token=? AND expires>?').bind(await hash(token),Date.now()).first();}
async function data(e,admin=false){const rows=(await e.DB.prepare('SELECT body,revision FROM questions ORDER BY id').all()).results;const sr=await e.DB.prepare('SELECT body,revision FROM settings WHERE id=1').first();if(!sr)throw Error('Run database migrations first');const questions=rows.map(r=>({...JSON.parse(r.body),revision:r.revision})).filter(q=>admin||!q.hidden).sort((a,b)=>(a.order||0)-(b.order||0)||a.id.localeCompare(b.id));return {languages:['nl','ar','uk','so','ckb'],questions,packs:Array.from({length:6},(_,i)=>({id:i+1,questions:questions.filter(q=>q.packIds.includes(i+1)).map(q=>q.id)})),settings:JSON.parse(sr.body),settingsRevision:sr.revision};}
async function handle(r,e){const u=new URL(r.url),p=u.pathname,m=r.method;
 if(p==='/api/login'&&m==='POST'){
  if(r.headers.get('origin')!==u.origin)return json({error:'Origin rejected'},403);
  if(!e.ADMIN_USER||!e.ADMIN_SALT||!e.ADMIN_HASH)return json({error:'Administrator secrets are not configured'},503);
  const ip=await hash(r.headers.get('CF-Connecting-IP')||'local');const now=Date.now();
  await e.DB.prepare('DELETE FROM login_attempts WHERE expires<?').bind(now).run();
  await e.DB.prepare('INSERT INTO login_attempts(ip,attempts,expires) VALUES(?,1,?) ON CONFLICT(ip) DO UPDATE SET attempts=attempts+1').bind(ip,now+900000).run();
  const attempt=await e.DB.prepare('SELECT attempts FROM login_attempts WHERE ip=?').bind(ip).first();if(attempt.attempts>10)return json({error:'Too many attempts. Wait 15 minutes.'},429);
  const b=await body(r,4096),got=await password(String(b.password||''),e.ADMIN_SALT);
  if(!equal(got,e.ADMIN_HASH)||!equal(String(b.username||''),e.ADMIN_USER))return json({error:'Invalid credentials'},401);
  await e.DB.prepare('DELETE FROM sessions WHERE expires<?').bind(now).run();
  const token=random(),csrf=random();await e.DB.prepare('INSERT INTO sessions VALUES(?,?,?)').bind(await hash(token),csrf,now+28800000).run();
  return json({csrf},200,{'Set-Cookie':`knm_session=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=28800`});
 }
 if(p==='/api/public'&&m==='GET')return json(await data(e));
 if(p.startsWith('/api/')){
  const session=await auth(r,e);if(!session)return json({error:'Authentication required'},401);
  if(m!=='GET'&&(r.headers.get('origin')!==u.origin||!equal(r.headers.get('x-knm-csrf'),session.csrf)))return json({error:'CSRF rejected'},403);
  if(p==='/api/admin'&&m==='GET')return json({...await data(e,true),csrf:session.csrf});
  if(p==='/api/logout'&&m==='POST'){await e.DB.prepare('DELETE FROM sessions WHERE token=?').bind(session.token).run();return json({ok:true},200,{'Set-Cookie':'knm_session=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0'});}
  if(p==='/api/backup'&&m==='GET')return json({format:'knm-1',...await data(e,true)},200,{'Content-Disposition':'attachment; filename="knm-data-backup.json"'});
  if(p==='/api/settings'&&m==='PUT'){const b=await body(r),s=validateSettings(b.settings);const result=await e.DB.prepare('UPDATE settings SET body=?,revision=revision+1 WHERE id=1 AND revision=?').bind(JSON.stringify(s),b.revision).run();return result.meta.changes?json({ok:true}):json({error:'Changed elsewhere; reload first'},409);}
  if(p==='/api/questions'&&m==='POST'){const q=validateQuestion(await body(r));const exists=await e.DB.prepare('SELECT id FROM questions WHERE id=?').bind(q.id).first();if(exists)return json({error:'ID already exists'},409);delete q.revision;await e.DB.prepare('INSERT INTO questions(id,body) VALUES(?,?)').bind(q.id,JSON.stringify(q)).run();return json({ok:true},201);}
  const match=p.match(/^\/api\/questions\/([-a-zA-Z0-9_]{1,80})$/);
  if(match&&m==='PUT'){const b=await body(r),rev=b.revision,q=validateQuestion(b);if(q.id!==match[1])return json({error:'ID mismatch'},400);delete q.revision;const result=await e.DB.prepare('UPDATE questions SET body=?,revision=revision+1 WHERE id=? AND revision=?').bind(JSON.stringify(q),q.id,rev).run();return result.meta.changes?json({ok:true}):json({error:'Changed elsewhere; reload first'},409);}
  if(match&&m==='DELETE'){const b=await body(r);const result=await e.DB.prepare('DELETE FROM questions WHERE id=? AND revision=?').bind(match[1],b.revision).run();return result.meta.changes?json({ok:true}):json({error:'Changed elsewhere; reload first'},409);}
  if(p==='/api/media'&&m==='POST'){
   if(Number(r.headers.get('content-length'))>5244000)return json({error:'Maximum 5 MiB'},413);
   const f=(await r.formData()).get('file');if(!f||typeof f.arrayBuffer!=='function'||f.size>5242880)return json({error:'Maximum 5 MiB'},400);
   const bytes=new Uint8Array(await f.arrayBuffer());let type='',ext='';
   if(bytes[0]===137&&bytes[1]===80&&bytes[2]===78&&bytes[3]===71){type='image/png';ext='png';}
   if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255){type='image/jpeg';ext='jpg';}
   if(String.fromCharCode(...bytes.slice(0,4))==='RIFF'&&String.fromCharCode(...bytes.slice(8,12))==='WEBP'){type='image/webp';ext='webp';}
   if(!type)return json({error:'Only PNG, JPEG, WebP'},400);
   const key=random()+'.'+ext;await e.MEDIA.put(key,bytes,{httpMetadata:{contentType:type}});return json({url:'/media/'+key},201);
  }
  return json({error:'Not found'},404);
 }
 if(p.startsWith('/media/')&&m==='GET'){const key=p.slice(7);if(!/^[a-f0-9]{64}\.(png|jpg|webp)$/.test(key))return new Response('Not found',{status:404});const f=await e.MEDIA.get(key);if(!f)return new Response('Not found',{status:404});return new Response(f.body,{headers:{'Content-Type':f.httpMetadata.contentType,'X-Content-Type-Options':'nosniff','Cache-Control':'public,max-age=31536000,immutable'}});}
 if(p==='/admin/')return Response.redirect(new URL('/admin',u),302);
 if(p==='/admin')u.pathname='/admin.html';
 if(p==='/')u.pathname='/index.html';
 return e.ASSETS.fetch(new Request(u,r));
}
export default {async fetch(r,e){try{return await handle(r,e);}catch(err){console.error('KNM request failed',err.message);return json({error:/Invalid|Complete|Choose|Use |Timer|Font|Navigation|Body|translations/.test(err.message)?err.message:'Request failed; check configuration and input'},400);}}};
