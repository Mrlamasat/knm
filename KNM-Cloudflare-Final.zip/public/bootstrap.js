'use strict';
(async()=>{
 try {
 const api=window.KNM_CONFIG?.api||'/api/';
 const response=await fetch(api+'public',{cache:'no-store'});if(!response.ok)throw Error('HTTP '+response.status);
 const d=await response.json();window.KNM_DATA=d;window.KNM_SETTINGS=d.settings;
 const signature=JSON.stringify(d.questions.map(q=>[q.id,q.revision]));
 try{if(localStorage.getItem('knm-bank-version')!==signature){localStorage.removeItem('knm-session-v1');localStorage.setItem('knm-bank-version',signature);}}catch{/* The quiz still works when browser storage is disabled. */}
 const s=d.settings,root=document.documentElement;
 root.style.setProperty('--blue',s.primary);root.style.setProperty('--orange',s.secondary);root.style.setProperty('--knm-primary',s.primary);root.style.fontSize=s.fontSize+'px';document.body.style.fontFamily=s.font;
 if(s.background)document.body.style.backgroundImage='url('+JSON.stringify(s.background)+')';
 document.title=s.title;
 const banner=document.createElement('div');banner.id='siteHeader';banner.className='site-extra';banner.textContent=s.header;
 const nav=document.createElement('nav');nav.className='site-nav';for(const n of s.navigation){const a=document.createElement('a');a.href=n.url;a.textContent=n.label;a.rel='noopener';nav.append(a);}banner.append(nav);document.querySelector('.topbar').after(banner);
 const footer=document.createElement('div');footer.className='site-extra';footer.textContent=s.footer;document.body.append(footer);
 if(s.logo){const img=document.createElement('img');img.src=s.logo;img.alt=s.title;img.className='site-logo';document.querySelector('.brand-mark').replaceChildren(img);}else document.querySelector('.brand-mark').textContent=s.icon;
 if(s.sectionOrder==='controls-first')document.body.classList.add('controls-first');
 const script=document.createElement('script');script.src='app.js';document.head.append(script);
 }catch(e){document.getElementById('app').textContent='تعذّر تحميل البيانات. تحقق من اتصالك وإعداد قاعدة البيانات ثم أعد تحميل الصفحة. / Unable to load quiz data.';console.error(e);}
})();
